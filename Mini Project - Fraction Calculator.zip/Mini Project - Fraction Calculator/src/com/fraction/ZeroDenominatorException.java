package com.fraction;

public class ZeroDenominatorException extends Exception {
	ZeroDenominatorException (String s) {
		super(s);
	}
}
